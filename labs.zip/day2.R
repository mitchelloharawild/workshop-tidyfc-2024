library(fpp3)

students_total <- students |> 
  summarise(enrolments = sum(`All Full-time and Part-time Student count`))

students_total |> 
  autoplot(enrolments)

fit <- students_total |> 
  model(
    drift = RW(enrolments ~ drift())
  )

fit |> 
  forecast(h = 10) |> 
  autoplot(students_total)

fit |> 
  gg_tsresiduals()

augment(fit) |> 
  ggplot(aes(x = .innov)) +
  geom_histogram(bins = 7)

augment(fit) |> 
  features(.innov, ljung_box, 6)



fit <- students_total |> 
  model(
    drift = MEAN(enrolments)
  )

fit |> 
  forecast(h = 10) |> 
  autoplot(students_total)

fit |> 
  gg_tsresiduals()

augment(fit) |> 
  ggplot(aes(x = .innov)) +
  geom_histogram(bins = 7)

augment(fit) |> 
  features(.innov, ljung_box, 6)


as_tsibble(USAccDeaths) |> 
  model(MEAN(value)) |> 
  gg_tsresiduals()
as_tsibble(USAccDeaths) |> 
  model(MEAN(value)) |> 
  augment() |> 
  gg_season(.innov)

aus_train <- aus_production |> 
  filter(year(Quarter) <= 2007)

aus_production |> 
  autoplot(Beer) + 
  autolayer(aus_train, Beer, colour = "red")

aus_train |> 
  model(
    SNAIVE(Beer)
  ) |> 
  forecast(h = "2 years") |> 
  autoplot(aus_production |> 
             filter(year(Quarter) >= 2000))

# In-sample (fitted values) accuracy
aus_train |> 
  model(
    SNAIVE(Beer),
    MEAN(Beer)
  ) |> 
  accuracy()

# Out-of-sample (forecast values) accuracy
aus_train |> 
  model(
    SNAIVE(Beer),
    MEAN(Beer)
  ) |> 
  forecast(h = "2 years") |> 
  accuracy(aus_production)


# Lab session 11
student_labour |> 
  distinct(attendance)
student_labour |> 
  distinct(status)
working_students <- student_labour |> 
  filter(
    attendance != "Not attending full-time education",
    status != "Not in the labour force (NILF)"
  ) |> 
  summarise(persons = sum(persons))

# Plot the data
working_students |> 
  autoplot(persons)

max(working_students$month)

# Model the data
fit <- working_students |> 
  filter(
    month <= yearmonth("2020 Aug")
  ) |> 
  model(
    drift = RW(persons ~ drift()),
    snaive = SNAIVE(persons)
  )
  
# In-sample (1-step) fitted accuracy
fit |> 
  accuracy()

# Out-of-sample (h-step) forecast accuracy
fit |> 
  forecast(h = "4 years") |> 
  accuracy(working_students)

# ┌──────────────────────┐
# │                      │
# │   Cross-validation   │
# │                      │
# └──────────────────────┘

working_students |> 
  stretch_tsibble(.step = 2*12, .init = 10*12) |> 
  mutate(.id = -.id) |> 
  autoplot()

# Model the data
fit <- working_students |> 
  # Training set creation
  # filter(
  #   month <= yearmonth("2020 Aug")
  # ) |> 
  
  # Cross-validation creation
  stretch_tsibble(.step = 2*12, .init = 10*12) |> 
  model(
    drift = RW(persons ~ drift()),
    snaive = SNAIVE(persons)
  )

# In-sample (1-step) fitted accuracy
fit |> 
  accuracy()

# Out-of-sample (h-step) forecast accuracy
fit |> 
  forecast(h = "4 years") |> 
  accuracy(working_students)
